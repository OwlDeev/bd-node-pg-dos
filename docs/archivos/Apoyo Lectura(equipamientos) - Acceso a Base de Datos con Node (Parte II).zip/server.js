const { agregarEquipamiento, obtenerEquipamientos } = require('./equipamiento')
const express = require('express');
const app = express();

app.listen(3001, console.log("SERVIDOR ENCENDIDO"))
app.use(express.json())

app.get("/equipamientos", async (req, res) => {
    const equipamientos = await obtenerEquipamientos()
    res.json(equipamientos)
})

app.post("/equipamientos", async (req, res) => {
    const { destino, presupuesto } = req.body
    await agregarEquipamiento(destino, presupuesto)
    res.send("Equipamiento agregado con éxito")
})