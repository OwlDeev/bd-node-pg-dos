const { Pool } = require('pg')

const pool = new Pool({
    host: 'localhost',
    user: 'postgres',
    password: 'postgres',
    database: 'plan_de_viajes',
    allowExitOnIdle: true
})

const agregarEquipamiento = async (destino, presupuesto) => {
    const consulta = "INSERT INTO equipamiento values (DEFAULT, $1, $2)"
    const values = [destino, presupuesto]
    const result = await pool.query(consulta, values)
    console.log("Equipamiento agregado")
}

const obtenerEquipamientos = async () => {
    const { rows } = await pool.query("SELECT * FROM equipamiento")
    console.log(rows)
    return rows
}

module.exports = { agregarEquipamiento, obtenerEquipamientos }